var searchData=
[
  ['init_5fanswer_64',['init_answer',['../answer_8c.html#ad49ac2577c64b69c749452255c77ecf7',1,'init_answer(void):&#160;answer.c'],['../answer_8h.html#ad49ac2577c64b69c749452255c77ecf7',1,'init_answer(void):&#160;answer.c']]]
];
