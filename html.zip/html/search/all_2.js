var searchData=
[
  ['color_2ec_18',['color.c',['../color_8c.html',1,'']]],
  ['color_2eh_19',['color.h',['../color_8h.html',1,'']]],
  ['compile_5fans_20',['compile_ans',['../answer_8c.html#aa85463dfb1c141c14c1a0addce53bbd9',1,'compile_ans(void):&#160;answer.c'],['../answer_8h.html#aa85463dfb1c141c14c1a0addce53bbd9',1,'compile_ans(void):&#160;answer.c']]],
  ['cur_5fpid_21',['cur_pid',['../grading_8c.html#abf7140d56f2663a9bb2d7510b828fdb1',1,'grading.c']]]
];
