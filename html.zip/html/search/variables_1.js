var searchData=
[
  ['cur_5fpid_86',['cur_pid',['../grading_8c.html#abf7140d56f2663a9bb2d7510b828fdb1',1,'grading.c']]]
];
