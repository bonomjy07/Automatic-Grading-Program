var searchData=
[
  ['red_66',['red',['../color_8c.html#aa6ef6b962547f5c050b2b1019b785079',1,'red(char *s):&#160;color.c'],['../color_8h.html#abfb0a50a3da98205560983882f3e3300',1,'red(char *):&#160;color.c']]]
];
