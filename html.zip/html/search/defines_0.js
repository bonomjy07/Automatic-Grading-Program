var searchData=
[
  ['ansi_5fcolor_5fblue_97',['ANSI_COLOR_BLUE',['../color_8h.html#aca16e6a49eb51333c5fd3eee19487315',1,'color.h']]],
  ['ansi_5fcolor_5fcyan_98',['ANSI_COLOR_CYAN',['../color_8h.html#a8d0b0043e152438bb39b918a1f98c65f',1,'color.h']]],
  ['ansi_5fcolor_5fgreen_99',['ANSI_COLOR_GREEN',['../color_8h.html#a966c72d8d733c7734c6c784753d894c7',1,'color.h']]],
  ['ansi_5fcolor_5fmagenta_100',['ANSI_COLOR_MAGENTA',['../color_8h.html#acb30614ba1535da5b9d0c490b3c10515',1,'color.h']]],
  ['ansi_5fcolor_5fred_101',['ANSI_COLOR_RED',['../color_8h.html#a34995b955465f6bbb37c359173d50477',1,'color.h']]],
  ['ansi_5fcolor_5freset_102',['ANSI_COLOR_RESET',['../color_8h.html#a92a364c2b863dde1a024a77eac2a5b3b',1,'color.h']]],
  ['ansi_5fcolor_5fyellow_103',['ANSI_COLOR_YELLOW',['../color_8h.html#a5a123b382640b3aa65dd5db386002fbc',1,'color.h']]]
];
