var searchData=
[
  ['search_5ffname_35',['search_fname',['../answer_8c.html#a65f9743330377a9705abdf4d7fa7e18c',1,'search_fname():&#160;answer.c'],['../grading_8c.html#a65f9743330377a9705abdf4d7fa7e18c',1,'search_fname():&#160;answer.c'],['../test_8c.html#a65f9743330377a9705abdf4d7fa7e18c',1,'search_fname():&#160;answer.c']]],
  ['sectors_36',['Sectors',['../grading_8c.html#a466708b5535ca2cd5c53fc37846c63c4',1,'grading.c']]],
  ['set_5fcreate_5fans_37',['set_create_ans',['../answer_8c.html#a6a6aef400d68b61e0ea16b9a4510b739',1,'set_create_ans(void):&#160;answer.c'],['../answer_8h.html#a6a6aef400d68b61e0ea16b9a4510b739',1,'set_create_ans(void):&#160;answer.c']]],
  ['set_5fdelete_5fans_38',['set_delete_ans',['../answer_8c.html#a36aeda15bfc3f16ead88967084ace225',1,'set_delete_ans(void):&#160;answer.c'],['../answer_8h.html#a36aeda15bfc3f16ead88967084ace225',1,'set_delete_ans(void):&#160;answer.c']]],
  ['set_5frsearch_5fans_39',['set_rsearch_ans',['../answer_8c.html#ae99c5a7a351eefabd2c46285fab86068',1,'set_rsearch_ans(void):&#160;answer.c'],['../answer_8h.html#ae99c5a7a351eefabd2c46285fab86068',1,'set_rsearch_ans(void):&#160;answer.c']]],
  ['set_5fsearch_5fans_40',['set_search_ans',['../answer_8c.html#a5ea303e5cf5c438db959f6b457f88112',1,'set_search_ans(void):&#160;answer.c'],['../answer_8h.html#a5ea303e5cf5c438db959f6b457f88112',1,'set_search_ans(void):&#160;answer.c']]],
  ['signal_5fhandler_41',['signal_handler',['../grading_8c.html#a6aa59f98cad89c73966351ad7afb303c',1,'signal_handler(int sig):&#160;grading.c'],['../grading_8h.html#a8804db44b6d4c5752e6de5593562df06',1,'signal_handler(int):&#160;grading.c']]]
];
