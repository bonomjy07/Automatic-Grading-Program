var searchData=
[
  ['red_33',['red',['../color_8c.html#aa6ef6b962547f5c050b2b1019b785079',1,'red(char *s):&#160;color.c'],['../color_8h.html#abfb0a50a3da98205560983882f3e3300',1,'red(char *):&#160;color.c']]],
  ['rsearch_5ffname_34',['rsearch_fname',['../answer_8c.html#a7129b97d56175d177e91de3ee12f1448',1,'rsearch_fname():&#160;answer.c'],['../grading_8c.html#a7129b97d56175d177e91de3ee12f1448',1,'rsearch_fname():&#160;answer.c'],['../test_8c.html#a7129b97d56175d177e91de3ee12f1448',1,'rsearch_fname():&#160;answer.c']]]
];
