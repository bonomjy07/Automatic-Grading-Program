var searchData=
[
  ['do_5fgrading_22',['do_grading',['../grading_8c.html#a9d7c673dfadcd1f10d2467bebca8d4e2',1,'do_grading(int *score):&#160;grading.c'],['../grading_8h.html#afb6069196bcb3516bdd587414f3d0eb2',1,'do_grading(int *):&#160;grading.c']]]
];
