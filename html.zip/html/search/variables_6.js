var searchData=
[
  ['test_5fptr_92',['test_ptr',['../grading_8c.html#acb6ba4f8c28f545fc2f0b4c14df8edf7',1,'grading.c']]]
];
