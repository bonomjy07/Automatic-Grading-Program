var searchData=
[
  ['yellow_81',['yellow',['../color_8c.html#aa64ea443ade2e1aee2813c8bfa73d67a',1,'yellow(char *s):&#160;color.c'],['../color_8h.html#a67846e793eb61ec5785629d373e93a47',1,'yellow(char *):&#160;color.c']]]
];
