var searchData=
[
  ['filter_62',['filter',['../grading_8c.html#a75102b030f4548d98f15d2c383b96f73',1,'filter(const struct dirent *info):&#160;grading.c'],['../grading_8h.html#a75102b030f4548d98f15d2c383b96f73',1,'filter(const struct dirent *info):&#160;grading.c']]]
];
