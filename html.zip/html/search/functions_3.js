var searchData=
[
  ['green_63',['green',['../color_8c.html#acdf9f0f2b56edbecdd4f6ada94775b7e',1,'green(char *s):&#160;color.c'],['../color_8h.html#a7c93eff6f285320cb21395794f3fcad4',1,'green(char *):&#160;color.c']]]
];
