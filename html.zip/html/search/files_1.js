var searchData=
[
  ['color_2ec_56',['color.c',['../color_8c.html',1,'']]],
  ['color_2eh_57',['color.h',['../color_8h.html',1,'']]]
];
