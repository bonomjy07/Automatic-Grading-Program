var searchData=
[
  ['answer_2ec_52',['answer.c',['../answer_8c.html',1,'']]],
  ['answer_2eh_53',['answer.h',['../answer_8h.html',1,'']]]
];
