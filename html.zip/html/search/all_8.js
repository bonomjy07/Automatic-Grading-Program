var searchData=
[
  ['main_31',['main',['../grading_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'grading.c']]]
];
