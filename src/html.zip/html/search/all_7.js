var searchData=
[
  ['id_5flength_29',['ID_LENGTH',['../grading_8h.html#a74cd4c8a601dffc9976cb2016f09dd0d',1,'grading.h']]],
  ['init_5fanswer_30',['init_answer',['../answer_8c.html#ad49ac2577c64b69c749452255c77ecf7',1,'init_answer(void):&#160;answer.c'],['../answer_8h.html#ad49ac2577c64b69c749452255c77ecf7',1,'init_answer(void):&#160;answer.c']]]
];
