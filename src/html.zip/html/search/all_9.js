var searchData=
[
  ['num_5fof_5fsector_32',['NUM_OF_SECTOR',['../grading_8h.html#a7d1d01ad9cc28e4a8e963580fda2e988',1,'grading.h']]]
];
