var searchData=
[
  ['print_5fanswer_68',['print_answer',['../answer_8c.html#afc3c6fe07d3b06e80e36bdcbdb6ca742',1,'print_answer(void):&#160;answer.c'],['../answer_8h.html#afc3c6fe07d3b06e80e36bdcbdb6ca742',1,'print_answer(void):&#160;answer.c']]],
  ['print_5ffile_69',['print_file',['../answer_8c.html#ad333c530511c02ed2b557c7adf19b25c',1,'print_file(char *buf):&#160;answer.c'],['../answer_8h.html#a1bc31fd3716c37174a3ad379df062cb6',1,'print_file(char *):&#160;answer.c']]]
];
