var searchData=
[
  ['id_5flength_105',['ID_LENGTH',['../grading_8h.html#a74cd4c8a601dffc9976cb2016f09dd0d',1,'grading.h']]]
];
