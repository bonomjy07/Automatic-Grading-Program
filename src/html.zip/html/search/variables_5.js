var searchData=
[
  ['search_5ffname_94',['search_fname',['../answer_8c.html#a65f9743330377a9705abdf4d7fa7e18c',1,'search_fname():&#160;answer.c'],['../grading_8c.html#a65f9743330377a9705abdf4d7fa7e18c',1,'search_fname():&#160;answer.c'],['../test_8c.html#a65f9743330377a9705abdf4d7fa7e18c',1,'search_fname():&#160;answer.c']]],
  ['sectors_95',['Sectors',['../grading_8c.html#a466708b5535ca2cd5c53fc37846c63c4',1,'grading.c']]]
];
